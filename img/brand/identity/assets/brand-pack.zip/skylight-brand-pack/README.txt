Skylight brand pack

Generated from skylight-hub plugins/skylight-brand-pack. Use these marks as the
brand guidelines describe: https://skylight.digital/company/brand/

icons/halo-grayscale-inverse.svg
  Grayscale Skylight halo logomark for dark backgrounds — used only when color is unavailable.

icons/halo-grayscale.svg
  Grayscale Skylight halo logomark for light backgrounds — used only when color is unavailable.

icons/halo-inverse.svg
  The Skylight halo logomark (color) in its dark-background inverse treatment.

icons/halo.svg
  The Skylight 'halo' logomark on its own — a circular form in the four brand colors (blue, green, ochre, red). Used as a standalone icon (favicon, app icon, compact brand mark) where the full logo doesn't fit. Full color, for light backgrounds.

logos/skylight-grayscale-inverse.svg
  Grayscale Skylight logo for dark backgrounds — used only when color reproduction is unavailable.

logos/skylight-grayscale.svg
  Grayscale (black-and-white) Skylight logo for light backgrounds — used only when color reproduction is unavailable.

logos/skylight-hubzone.svg
  The Skylight logo paired with the SBA HUBZone certification mark. For government-contracting surfaces where HUBZone set-aside status matters; most external surfaces use the standard logo without it. (Internal-extension variant — not in the base brand guidelines.)

logos/skylight-inverse.svg
  Standard Skylight logo (wordmark + multicolor halo) in its dark-background inverse treatment, for sanctioned dark colors (gray-300, red-200, blue-300, green-300).

logos/skylight-logo.svg
  Standard Skylight logo — the 'Skylight' logotype in its custom typeface followed by the halo logomark (a circular form in the four brand colors: blue, green, ochre, red). For light backgrounds; the canonical brand mark used on most surfaces.

logos/skylight-one-color-inverse.svg
  One-color Skylight logo for single-color reproduction on dark backgrounds.

logos/skylight-one-color.svg
  One-color Skylight logo for single-color reproduction constraints (embroidery, etched signage, single-color print) on light backgrounds.

